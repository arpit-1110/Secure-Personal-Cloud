Two Fish
=======

Twofish (ECB and CBC) javascript implementation.

References to https://www.schneier.com/twofish.html
