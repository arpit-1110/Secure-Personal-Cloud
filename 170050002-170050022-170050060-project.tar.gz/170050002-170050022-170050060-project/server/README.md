# Secure-Personal-Cloud
Cloud based file sharing system (CS 251 Project)

Run client_setup.sh to setup client
Run server_setup.sh to setup server
